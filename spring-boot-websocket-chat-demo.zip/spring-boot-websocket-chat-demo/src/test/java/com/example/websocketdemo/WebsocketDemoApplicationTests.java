package com.example.websocketdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WebsocketDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
